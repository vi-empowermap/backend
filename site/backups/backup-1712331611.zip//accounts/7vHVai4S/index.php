<?php

return [
    'email' => 'orga2@gmail.com',
    'language' => 'en',
    'name' => 'orga2',
    'role' => 'orga'
];