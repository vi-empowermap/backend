<?php

return [
    'email' => 'testuser@gmail.com',
    'language' => 'en',
    'name' => 'testuser',
    'role' => 'orga'
];