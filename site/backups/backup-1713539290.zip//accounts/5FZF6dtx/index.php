<?php

return [
    'email' => 'testuser2@gmail.com',
    'language' => 'en',
    'name' => 'testuser2(viewer)',
    'role' => 'systemadmin'
];