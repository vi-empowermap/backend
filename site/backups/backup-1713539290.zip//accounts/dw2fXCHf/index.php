<?php

return [
    'email' => 'orga7@gmail.com',
    'language' => 'en',
    'name' => NULL,
    'role' => 'orga'
];