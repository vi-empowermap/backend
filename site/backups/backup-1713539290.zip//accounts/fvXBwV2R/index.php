<?php

return [
    'email' => 'orga8@gmail.com',
    'language' => 'en',
    'name' => NULL,
    'role' => 'orga'
];