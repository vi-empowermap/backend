<?php

return [
    'email' => 'zndgn555@gmail.com',
    'language' => 'en',
    'name' => '',
    'role' => 'admin'
];