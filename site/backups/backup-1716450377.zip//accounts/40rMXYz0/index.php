<?php

return [
    'email' => 'orga3@gmail.com',
    'language' => 'en',
    'name' => NULL,
    'role' => 'orga'
];