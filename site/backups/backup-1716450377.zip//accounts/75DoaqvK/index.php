<?php

return [
    'email' => 'orga23@gmail.com',
    'language' => 'en',
    'name' => NULL,
    'role' => 'orga'
];