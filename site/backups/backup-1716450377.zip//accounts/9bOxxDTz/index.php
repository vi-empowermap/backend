<?php

return [
    'email' => 'orga5@gamil.com',
    'language' => 'en',
    'name' => NULL,
    'role' => 'orga'
];