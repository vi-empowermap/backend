<?php

return [
    'email' => 'orga4@gmail.com',
    'language' => 'en',
    'name' => NULL,
    'role' => 'orga'
];