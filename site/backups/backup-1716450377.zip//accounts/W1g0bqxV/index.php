<?php

return [
    'email' => 'orga6@gmail.com',
    'language' => 'en',
    'name' => NULL,
    'role' => 'orga'
];