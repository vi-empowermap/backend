<?php

return [
    'email' => 'orga2@gmail.com',
    'language' => 'en',
    'name' => NULL,
    'role' => 'orga'
];