<?php

return [
    'email' => 'subtestuser@gmail.com',
    'language' => 'en',
    'name' => 'subtestuser',
    'role' => 'subsystemadmin'
];