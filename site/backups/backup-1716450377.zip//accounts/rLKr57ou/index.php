<?php

return [
    'email' => 'orga9@gmail.com',
    'language' => 'en',
    'name' => NULL,
    'role' => 'orga'
];